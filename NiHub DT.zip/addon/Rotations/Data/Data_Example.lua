ni.data.example = {
	ishelloprinted = false
}
